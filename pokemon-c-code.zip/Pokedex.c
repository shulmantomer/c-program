/* file: Pokedex.c */

#include "Pokemon.h"
#include "Defs.h"

#define MAX_LINE 300
/**
 * Prints the details of all Pokemons in the provided array.
 *
 * @param num The number of Pokemons in the array.
 * @param pokes An array of pointers to Pokemon structures to be printed.
 */
void print_pokemons(int num, Pokemon **pokes) {
	for (int i = 0; i < num; i++) {
		print_pokemon(pokes[i]);
	}
}
/**
 * Prints the details and relationships of all Types in the provided array.
 *
 * @param num The number of Types in the array.
 * @param types An array of pointers to Type structures to be printed.
 */
void print_types(int num, Type **types) {
	for (int i = 0; i < num; i++) {
		print_type(types[i]);
	}
}
/**
 * Finds a Type by its name among a list of Types.
 *
 * @param types An array of pointers to Type structures.
 * @param numTypes The number of Types in the array.
 * @param name The name of the Type to find.
 * @return A pointer to the found Type structure, or NULL if the Type is not found.
 */
Type* findTypeByName(Type **types, int numTypes, char *name) {
	//printf("the name is %s \n", name);
	for (int i = 0; i < numTypes; i++) {
		if (strcmp(types[i]->name_type, name) == 0) {
			return types[i];
		}
	}
	return NULL; // Not found
}
/**
 * Finds the index of a Type by its name in a list of Types.
 *
 * @param typeName The name of the Type to find.
 * @param types An array of pointers to Type structures.
 * @param numTypes The number of Types in the array.
 * @return The index of the Type in the array if found, -1 otherwise.
 */
int findTypeIndex(char *typeName, Type **types, int numTypes) {
	for (int i = 0; i < numTypes; i++) {
		if (strcmp(types[i]->name_type, typeName) == 0) {
			return i; // Found the type, return its index
		}
	}
	return -1; // Type not found
}
/**
 * Reads and initializes Types and their relationships from a file.
 *
 * @param file Pointer to the file to read from.
 * @param types An array of pointers to store the initialized Type structures.
 * @param numTypes The number of Types expected to be read and initialized.
 */
void readTypesAndRelationships(FILE *file, Type **types, int numTypes) {
	char line[MAX_LINE];
	// Read and create all types
	fgets(line, MAX_LINE, file); // Assumes "Types" line is already read
	line[strcspn(line, "\r\n")] = 0;
	char *token = strtok(line, ",");
	for (int i = 0; i < numTypes; i++) {
		if (token == NULL)
			break;
		types[i] = create_type(token);
		token = strtok(NULL, ",");
	}

	// Read relationships until it found Pokemons
	while (fgets(line, MAX_LINE, file) && strncmp(line, "Pokemons", 8) != 0) {

		if (strlen(line) <= 1)
			continue; // Skip empty lines
		line[strcspn(line, "\r\n")] = 0;
		char* word=strtok(line, "\t");
		word = strtok(word," ");
		Type *type = findTypeByName(types, numTypes, word);

		char *relationType = strtok(NULL, ":");
		char *targetTypeName = strtok(NULL, ",\n");
		while (targetTypeName != NULL) {

			Type *targetType = findTypeByName(types, numTypes, targetTypeName);
			if (targetType) {
				
				if (strstr(relationType, "effective-against-me")) {
					add_effective_against_me(type, targetType);
					
				} 
				else if (strstr(relationType, "effective-against-other")) {
					add_effective_against_others(type, targetType);
				}
			}
			targetTypeName = strtok(NULL, ",\n");
		}
	}
}
/**
 * Reads and initializes Pokemons from a file, assigning them to their respective Types.
 *
 * @param file Pointer to the file to read from.
 * @param pokemons An array of pointers to store the initialized Pokemon structures.
 * @param numPokemons The number of Pokemons expected to be read and initialized.
 * @param types An array of pointers to Type structures for assigning Types to Pokemons.
 * @param numTypes The number of Types available in the types array.
 */
void readPokemons(FILE *file, Pokemon **pokemons, int numPokemons, Type **types,
		int numTypes) {
	char line[MAX_LINE];
	for (int i = 0; i < numPokemons; i++) {
		if (!fgets(line, MAX_LINE, file))
			break;
		line[strcspn(line, "\r\n")] = 0;
		char *name = strtok(line, ",");
		char *species = strtok(NULL, ",");
		float height = atof(strtok(NULL, ","));
		float weight = atof(strtok(NULL, ","));
		int attack = atoi(strtok(NULL, ","));
		char *typeName = strtok(NULL, ",\n");

		Type *type = findTypeByName(types, numTypes, typeName);
		Biology bio = { height, weight, attack }; 
		pokemons[i] = create_poke(name, species, type, height, weight, attack);

	}
}

int main(int argc, char *argv[]) {

	int numTypes = atoi(argv[1]);
	int numPokes = atoi(argv[2]);
	char line[MAX_LINE];
	char typename[MAX_LINE];
	int typeIndex;
	int againstIndex;
	FILE *file = fopen(argv[3], "r");
	if (!file) {
		printf("Error opening file");
		fclose(file);
		return 1;
	}
	Type **types = (Type**) malloc(sizeof(Type*) * numTypes);
	Pokemon **pokemons = (Pokemon**) malloc(sizeof(Pokemon*) * numPokes);
	if (types == NULL || pokemons == NULL) {
		printf("Memory Problem");
		fclose(file);
		return 1;
	}
	while (fgets(line, MAX_LINE, file) && strncmp(line, "Types", 5) != 0);
	readTypesAndRelationships(file, types, numTypes);
	readPokemons(file, pokemons, numPokes, types, numTypes);

	fclose(file);
	char ch;
	do {
		printf("Please choose one of the following numbers:\n");
		printf("1 : Print all Pokemons\n");
		printf("2 : Print all Pokemons types\n");
		printf("3 : Add type to effective against me list\n");
		printf("4 : Add type to effective against others list\n");
		printf("5 : Remove type from effective against me list\n");
		printf("6 : Remove type from effective against others list\n");
		printf("7 : Print Pokemon by name\n");
		printf("8 : Print Pokemons by type\n");
		printf("9 : Exit\n");
		scanf(" %s", &ch);

		switch (ch) {
		case '1':
			print_pokemons(numPokes, pokemons);
			break;
		case '2':
			print_types(numTypes, types);
			break;
		case '3':
			printf("Please enter type name:\n");
			scanf("%s", typename);
			typeIndex = findTypeIndex(typename, types, numTypes);
			if (typeIndex == -1) {

				printf("Type name doesn't exist.\n");
				break;
			}
			printf("Please enter type name to add to %s effective against me list:\n",typename);
			scanf("%s", typename);
			againstIndex = findTypeIndex(typename,types, numTypes);
			if (againstIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			if (add_effective_against_me(types[typeIndex], types[againstIndex])
					== SUCCESS) {
				print_type(types[typeIndex]);
			} else {
				printf("This type already exist in the list.\n");

			}
			break;
		case '4':
			printf("Please enter type name:\n");
			scanf("%s", typename);
			typeIndex = findTypeIndex(typename, types, numTypes);
			if (typeIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			printf("Please enter type name to add to %s effective against others list:\n",typename);
			scanf("%s", typename);
			againstIndex = findTypeIndex(typename,types, numTypes);
			if (againstIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			if (add_effective_against_others(types[typeIndex],
					types[againstIndex]) == SUCCESS) {
				print_type(types[typeIndex]);
			} else {
				printf("This type is already exist in the list.\n");
				break;
			}
			break;
		case '5':
			printf("Please enter type name:\n");
			scanf("%s", typename);
			typeIndex = findTypeIndex(typename, types, numTypes);
			if (typeIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			
			printf("Please enter type name to remove from %s effective against me list:\n",typename);
			scanf("%s", typename);
			
			
			againstIndex = findTypeIndex(typename,types, numTypes);
			if (againstIndex == -1) {
				printf("Type name doesn't exist in the list.\n");
				break;
			}
			// Check if againstType is in the mainType's effective against me list
			int inAgainstList = -1; // Assume against type is not found initially
			for (int i = 0; i < types[typeIndex]->num_against_me; i++) {
				if (types[typeIndex]->effective_against_me[i] == types[againstIndex]) {
					inAgainstList = i; // Found the againstType in the list
			        break;
			    }
			    }

			if (inAgainstList == -1) {
				printf("Type name doesn't exist in the list.\n");
			    break;
			    }

			delete_effective_against_me(types[typeIndex], types[againstIndex]);
			print_type(types[typeIndex]);
			break;
		case '6':
			printf("Please enter type name:\n");
			scanf("%s", typename);
			typeIndex = findTypeIndex(typename, types, numTypes);
			if (typeIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			printf("Please enter type name to remove from %s effective against others list:\n",typename);
			scanf("%s", typename);
			againstIndex = findTypeIndex(typename,types, numTypes);
			if (againstIndex == -1) {
				printf("Type name doesn't exist in the list.\n");
				break;
			}
			inAgainstList = -1; // Assume against type is not found initially
			for (int i = 0; i < types[typeIndex]->num_against_others; i++) {
				if (types[typeIndex]->effective_against_others[i] == types[againstIndex]) {
					inAgainstList = i; // Found the againstType in the list
					break;
				}
			}

			if (inAgainstList == -1) {
				printf("Type name doesn't exist in the list.\n");
				break;
			}

			delete_effective_against_others(types[typeIndex],types[againstIndex]);
			print_type(types[typeIndex]);
			break;
		case '7':
			printf("Please enter Pokemon name:\n");
			scanf("%s", typename);
			int found = 0;
			for (int i = 0; i < numPokes; i++) {
				if (strcmp(pokemons[i]->name_poke, typename) == 0) {
					print_pokemon(pokemons[i]);
					found = 1;
					break;
				}
			}
			if (!found) {
				printf("The Pokemon doesn't exist.\n");
			}
			break;
		case '8':
			printf("Please enter type name:\n");
			scanf("%s", typename);
			typeIndex = findTypeIndex(typename, types, numTypes);
			int count = 0;
			if (typeIndex == -1) {
				printf("Type name doesn't exist.\n");
				break;
			}
			for (int i = 0; i < numPokes; i++)
			{
				if (strcmp(pokemons[i]->type_of_poke->name_type, typename) == 0) {
					count++;
			}
			}	
			if (count == 0) {
				printf("There are no Pokemons with this type.\n");
				break;
			}
			else {
				printf("There are %d Pokemons with this type:\n",count);
			}
			for (int i = 0; i < numPokes; i++) {
				if (strcmp(pokemons[i]->type_of_poke->name_type, typename) == 0) {
					print_pokemon(pokemons[i]);
				}

			}
			

			break;

		case '9':
		    destroy_all(pokemons, types, numPokes, numTypes);
		    printf("All the memory cleaned and the program is safely closed.\n");
		    break;

		default:
			printf("Please choose a valid number. \n");

		}
	} while (ch != '9');
	return 0;
}
