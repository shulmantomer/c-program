
#ifndef Defs_h
#define Defs_h
typedef enum e_status{SUCCESS,FAILURE}status;


#endif /* Defs_h */
