

#ifndef Pokemon_h
#define Pokemon_h
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Defs.h"
typedef struct pokemon_type {
	char* name_type;
	struct pokemon_type** effective_against_me;
	struct pokemon_type** effective_against_others;
	int num; 
	int num_against_me;
	int num_against_others;

} Type;

typedef struct biology_info {
	float height;
	float weight;
	int attack;

} Biology;

typedef struct poke{
	char* name_poke;
	char* species;
	Type* type_of_poke;
	Biology* bio;

} Pokemon;
Pokemon* create_poke(char*, char*,Type*,float,float,int);
Type* create_type(char* );
Biology* create_bio(float, float, int );
status add_effective_against_me(Type*, Type*);
status add_effective_against_others(Type*,Type*);
status delete_effective_against_me(Type*,Type*);
status delete_effective_against_others(Type*,Type*);
status print_pokemon(Pokemon*);
status print_type(Type*);
void destroy_all(Pokemon**,Type**,int,int);
#endif /* Pokemon_h */
