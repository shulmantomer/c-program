
#include <stdio.h>
#include <stdlib.h>
#include "Pokemon.h"
#include "Defs.h"
/**
 * Allocates and initializes a new Pokemon structure.
 *
 * @param name_poke The name of the Pokemon.
 * @param species The species of the Pokemon.
 * @param type_poke Pointer to the Type structure the Pokemon belongs to.
 * @param height The height of the Pokemon.
 * @param weight The weight of the Pokemon.
 * @param attack The attack value of the Pokemon.
 * @return A pointer to the newly created Pokemon structure, or NULL if memory allocation fails.
 */
Pokemon* create_poke(char* name_poke, char* species,Type* type_poke,float height,float weight,int attack){
	Pokemon* new_poke = (Pokemon *)malloc(sizeof(Pokemon));
	if (new_poke == NULL)
	{
		printf("Memory Problem");
		return NULL;
	}

	char* name_of_poke = (char*)malloc((strlen(name_poke)+1)*sizeof(char));
	char* namespecies = (char*)malloc((strlen(species)+1)*sizeof(char));
	if (namespecies==NULL || name_of_poke==NULL){
			printf("Memory Problem");
			return NULL;
		}
	strcpy(name_of_poke,name_poke);
	new_poke->name_poke = name_of_poke;
	strcpy(namespecies,species);
	new_poke->species =namespecies;
	new_poke->type_of_poke=type_poke;
	type_poke->num++;
	new_poke->bio=create_bio(height,weight,attack);
	return new_poke;
}
/**
 * Allocates and initializes a new Type structure.
 *
 * @param name_type The name of the type.
 * @return A pointer to the newly created Type structure, or NULL if memory allocation fails.
 */
Type* create_type(char* name_type){
	Type* new_type= (Type *)malloc(sizeof(Type));
	if(new_type==NULL){
		printf("Memory Problem");
		return NULL;
	}
	new_type->num=0;
	new_type->num_against_me=0;
	new_type->num_against_others=0;
	new_type-> effective_against_me=NULL;
	new_type-> effective_against_others=NULL;
	
	char* name_of_type = (char*)malloc((strlen(name_type)+1)*sizeof(char));

	if (name_of_type==NULL)
	{
		printf("Memory Problem");
		free(name_of_type);
		return NULL;
	}
	strcpy(name_of_type,name_type);

	new_type ->name_type = name_of_type;


	return new_type;
}

/**
 * Allocates and initializes a new Biology structure.
 *
 * @param height The height attribute for the Biology structure.
 * @param weight The weight attribute for the Biology structure.
 * @param attack The attack attribute for the Biology structure.
 * @return A pointer to the newly created Biology structure, or NULL if memory allocation fails.
 */
Biology* create_bio(float height, float weight,int attack){
	Biology* new_biology = (Biology *)malloc(sizeof(Biology));

	if (new_biology == NULL)
	{
		printf("Memory Problem");
		return NULL;
	}
	new_biology->height=height;
	new_biology->weight=weight;
	new_biology->attack=attack;

	return new_biology;
}
/**
 * Checks if a given Type is in the "effective against me" list.
 *
 * @param B The Type to check.
 * @param num_against_me The number of types in the "effective against me" list.
 * @param effective_against_me The list of types that are "effective against me".
 * @return The index of Type B in the list if found, -1 otherwise.
 */
int type_index_check_me(Type* B,int num_against_me, Type** effective_against_me){
	for( int i=0; i<num_against_me;i++){
		if(B == effective_against_me[i]){
			return i;
		}

	}
	return -1; // B is not found in the array

}
/**
 * Adds a Type to another Type's "effective against me" list.
 *
 * @param A The Type to add to.
 * @param B The Type to be added.
 * @return SUCCESS if the addition was successful, FAILURE otherwise.
 */
status add_effective_against_me(Type* A, Type* B){
	if (A == NULL && B!=NULL){
		return FAILURE;
	}	
	// if B is already in the effetive against me return failure
	if(type_index_check_me(B,A->num_against_me,A->effective_against_me) != -1){
		return FAILURE;
	}
	// resize the effective against me array
	Type** newArray = (Type**)realloc(A->effective_against_me,(A->num_against_me+1)*sizeof(Type*));
	if (newArray == NULL){
		printf("Memory Problem");
		return FAILURE;
	}
	A->effective_against_me = newArray;
	A->effective_against_me[A->num_against_me] = B;
	A->num_against_me++;

	return SUCCESS;
}
/**
 * Checks if a given Type is in the "effective against others" list.
 *
 * @param B The Type to check.
 * @param num_against_others The number of types in the "effective against others" list.
 * @param effective_against_others The list of types that are "effective against others".
 * @return The index of Type B in the list if found, -1 otherwise.
 */
int type_index_check_others(Type* B,int num_against_others, Type** effective_against_others){
	for( int i=0; i<num_against_others;i++){
		if(B == effective_against_others[i]){
			return i;
		}

	}
	return -1; // B is not found in the array

}

/**
 * Adds a Type to another Type's "effective against others" list.
 *
 * @param A The Type to add to.
 * @param B The Type to be added.
 * @return SUCCESS if the addition was successful, FAILURE otherwise.
 */
status add_effective_against_others(Type* A,Type* B){
	if (A== NULL || B== NULL){
			return FAILURE;
		}
		// if B is already in the effetive against others return failure
		if(type_index_check_others(B,A->num_against_others,A->effective_against_others) != -1){
			return FAILURE;
		}
		// resize the effective against me others
		Type** newArray = (Type**)realloc(A->effective_against_others,(A->num_against_others+1)*sizeof(Type*));
		if (newArray == NULL){
			printf("Memory Problem");
			return FAILURE;
		}
		A->effective_against_others = newArray;
		A->effective_against_others[A->num_against_others] = B;
		A->num_against_others++;

		return SUCCESS;
}
/**
 * Removes a Type from another Type's "effective against me" list.
 *
 * @param A The Type to remove from.
 * @param B The Type to be removed.
 * @return SUCCESS if the removal was successful, FAILURE otherwise.
 */
status delete_effective_against_me(Type* A,Type* B){

	if (A==NULL || B==NULL ||A->effective_against_me==NULL )
	{
		return FAILURE;
	}
	int index =type_index_check_me(B, A->num_against_me,A->effective_against_me);
	if (index== -1){
		return FAILURE;
	}
	for (int j=index; j<A->num_against_me-1;j++){
		A->effective_against_me[j] = A->effective_against_me[j+1];
	}
	A->num_against_me--;
	A->effective_against_me = realloc(A->effective_against_me,A->num_against_me* sizeof(Type*));

	return SUCCESS;

}
/**
 * Removes a Type from another Type's "effective against others" list.
 *
 * @param A The Type to remove from.
 * @param B The Type to be removed.
 * @return SUCCESS if the removal was successful, FAILURE otherwise.
 */
status delete_effective_against_others(Type* A,Type* B){
	if (A==NULL || B==NULL ||A->effective_against_others==NULL )
		{
			return FAILURE;
		}
		int index =type_index_check_others(B, A->num_against_others,A->effective_against_others);
		if (index== -1){
			return FAILURE;
		}
		for (int j=index; j<A->num_against_others-1;j++){
			A->effective_against_others[j] = A->effective_against_others[j+1];
		}
		A->num_against_others--;
		A->effective_against_others = realloc(A->effective_against_others,A->num_against_others* sizeof(Type*));

		return SUCCESS;

}
/**
 * Prints the details of a Pokemon.
 *
 * @param pokemon The Pokemon to print.
 * @return SUCCESS if the Pokemon exists and was printed, FAILURE otherwise.
 */
status print_pokemon(Pokemon* pokemon){
	if (pokemon == NULL){
		return FAILURE;
	}

	printf("%s :\n%s, %s Type.\n", pokemon->name_poke, pokemon->species, pokemon->type_of_poke->name_type);
	printf("Height: %.2f m    Weight: %.2f kg    Attack: %d\n\n", pokemon->bio->height, pokemon->bio->weight, pokemon->bio->attack);

	return SUCCESS;
}

/**
 * Prints the details and relationships of a Type.
 *
 * @param type The Type to print.
 * @return SUCCESS if the Type exists and was printed, FAILURE otherwise.
 */
status print_type(Type* type){
	if (type ==NULL){
		return FAILURE;
	}
	printf("Type %s -- %d pokemons\n", type->name_type, type->num);
	if (type->num_against_me>0){
		printf("\tThese types are super-effective against %s:", type->name_type);
		for (int i=0;i<type->num_against_me;i++){
			if (i!=0){
				printf(" ,");
			}
			printf("%s", type->effective_against_me[i]->name_type);

		}
		printf("\n");
	}
	if (type->num_against_others>0)
	{
		printf("\t%s moves are super-effective against:", type->name_type);
			for (int j=0;j<type->num_against_others;j++){
				if (j!=0){
					printf(" ,");
				}
				printf("%s", type->effective_against_others[j]->name_type);

			}
			printf("\n");
		}
	printf("\n\n");
	return SUCCESS;


}

/**
 * Frees all allocated memory for Pokemons and Types.
 *
 * @param poke The array of Pokemon pointers.
 * @param type The array of Type pointers.
 * @param num_pokes The number of Pokemons.
 * @param num_types The number of Types.
 */
void destroy_all(Pokemon** pokemon, Type** type, int num_pokemon, int num_types) {
    // free all Pokemons
    for (int i = 0; i < num_pokemon; i++) {
        if (pokemon[i] != NULL) {
            
        	free(pokemon[i]->name_poke);
        	pokemon[i]->name_poke = NULL;
        	free(pokemon[i]->bio);
        	pokemon[i]->bio = NULL;
        	free(pokemon[i]->species);
        	pokemon[i]->species = NULL;
            free(pokemon[i]);
            pokemon[i] = NULL;
        }
    }
    free(pokemon); // Free the array of pointers itself

    // free all Types, including their dynamically allocated fields
    for (int j = 0; j < num_types; j++) {
        if (type[j] != NULL) {
            free(type[j]->name_type);
            type[j]->name_type = NULL;
            free(type[j]->effective_against_me); 
            type[j]-> effective_against_me =NULL;
            free(type[j]->effective_against_others);
            type[j]->effective_against_others= NULL;
            free(type[j]); // free the Type itself
            type[j] = NULL;
        }
    }
    free(type); // Free the array of pointers itself
}
